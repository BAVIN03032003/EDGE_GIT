"""
Manual Platform Plugin: QSYSCorePlugin
"""

import socket
import json
import threading
import time
import re
import asyncio
import subprocess
import platform
import requests
import xml.etree.ElementTree as ET

from .base import ManualPlatformPlugin



class QSYSCorePlugin(ManualPlatformPlugin):
    """Q-SYS Core Audio/Video Platform Plugin and control too"""
    
    name = "qsys"
    display_name = "Q-SYS"
    description = "QSC Q-SYS Core Monitoring"
    supports_display_id = False
    supports_port = False
    default_port = 443
    
    COMMANDS = {}
    
    QUERY_COMMANDS = {}
    
    def parse_xml_field(self, root, path):
        """Helper to safely get XML field text"""
        elem = root.find(path)
        return elem.text.strip() if elem is not None and elem.text else None

    def _first_non_empty(self, values):
        for value in values:
            if value:
                return value.strip() if isinstance(value, str) else value
        return None

    def _extract_serial_from_html(self, ip):
        """Best-effort serial extraction from status page HTML."""
        try:
            resp = requests.get(f"https://{ip}/#status", timeout=5, verify=False)
            if resp.status_code != 200:
                return None

            html = resp.text
            import re
            patterns = [
                r'"serial_no"\s*:\s*"([^"]+)"',
                r'"serialNumber"\s*:\s*"([^"]+)"',
                r"device\.serial_no[^>]*>\s*([^<\s][^<]*)<"
            ]
            for pattern in patterns:
                match = re.search(pattern, html, flags=re.IGNORECASE)
                if match:
                    value = match.group(1).strip()
                    if value:
                        return value
        except Exception:
            pass
        return None

    def _extract_serial_with_selenium(self, ip):
        """Optional Selenium fallback for pages rendered fully via JS."""
        try:
            from selenium import webdriver
            from selenium.webdriver.chrome.options import Options
            from selenium.webdriver.common.by import By
        except Exception:
            return None

        driver = None
        try:
            options = Options()
            options.add_argument("--headless")
            options.add_argument("--ignore-certificate-errors")
            options.add_argument("--log-level=3")
            driver = webdriver.Chrome(options=options)
            driver.set_page_load_timeout(10)
            driver.get(f"https://{ip}/#status")
            time.sleep(2)

            selectors = [
                (By.XPATH, '//div[@x-text="device.serial_no"]'),
                (By.XPATH, '//*[@x-text="device.serial_no"]')
            ]
            for by, selector in selectors:
                try:
                    elem = driver.find_element(by, selector)
                    serial = (elem.text or "").strip()
                    if serial:
                        return serial
                except Exception:
                    continue
        except Exception:
            return None
        finally:
            if driver:
                try:
                    driver.quit()
                except Exception:
                    pass
        return None
    
    def get_device_info(self, ip, port=443, display_id=None):
        """Get device info via Q-SYS XML Status API"""
        import platform
        import subprocess
        import re
        
        def ping_host():
            param = "-n" if platform.system().lower() == "windows" else "-c"
            try:
                result = subprocess.run(["ping", param, "1", ip], capture_output=True, timeout=3)
                return result.returncode == 0
            except:
                return False
        
        is_online = ping_host()
        
        device_info = {
            "ip_address": ip,
            "port": port,
            "display_id": display_id,
            "make": "QSC",
            "firmware_version" : None,
            "device_name": None,
            "model": None,
            "serial_number": None,
            "mac_address": None,
            "current_status": "Online" if is_online else "Offline",
        }
        
        # Always try to fetch XML status if possible, even if ping failed
        try:
            url = f"https://{ip}/cgi-bin/status_xml"
            resp = requests.get(url, timeout=5, verify=False)
            
            if resp.status_code == 200:
                is_online = True # If we can reach the API, the device is definitely online
                device_info["current_status"] = "Online"
                
                root = ET.fromstring(resp.text)
                serial_from_xml = self._first_non_empty([
                    self.parse_xml_field(root, "serial_number"),
                    self.parse_xml_field(root, "serial_no"),
                    self.parse_xml_field(root, "device_serial_number"),
                    self.parse_xml_field(root, "device/serial_number"),
                    self.parse_xml_field(root, "device/serial_no"),
                ])

                device_info.update({
                    "device_name": self.parse_xml_field(root, "device_name"),
                    "device_type": self.parse_xml_field(root, "device_type"),
                    "model": self.parse_xml_field(root, "device_model_pretty"),
                    "firmware": self.parse_xml_field(root, "firmware_version"),
                    "design_name": self.parse_xml_field(root, "design/pretty_name"),
                    "design_status": self.parse_xml_field(root, "design/state_pretty"),
                    "mac_address": self.parse_xml_field(root, "network_interfaces/network_interface/mac_address"),
                    "uptime": self.parse_xml_field(root, "design/uptime"),
                    "serial_number": serial_from_xml,
                })

                # Your device publishes serial in the JS status page on some firmware builds.
                if not device_info.get("serial_number"):
                    device_info["serial_number"] = self._extract_serial_from_html(ip)

                if not device_info.get("serial_number") and self.config.get("use_selenium_serial", True):
                    device_info["serial_number"] = self._extract_serial_with_selenium(ip)

        except Exception as e:
            if is_online: # Only log error if we thought it was online via ping but API failed
                device_info["error"] = str(e)
        
        if not device_info.get("serial_number"):
            device_info["serial_number"] = device_info.get("mac_address")

        if not device_info.get("device_name"):
            device_info["device_name"] = device_info.get("model") or f"Q-SYS {ip}"
        
        return device_info
    
    def send_command(self, ip, port, display_id, command):
        """Q-SYS is monitoring-only, no control commands"""
        return False, "Q-SYS is monitoring-only. Control commands not supported."
    
    def query_status(self, ip, port=443, display_id=None):
        """Query Q-SYS device status"""
        status = {}
        
        try:
            url = f"https://{ip}/cgi-bin/status_xml"
            resp = requests.get(url, timeout=5, verify=False)
            
            if resp.status_code == 200:
                root = ET.fromstring(resp.text)
                
                status.update({
                    "device_name": self.parse_xml_field(root, "device_name"),
                    "device_type": self.parse_xml_field(root, "device_type"),
                    "model": self.parse_xml_field(root, "device_model_pretty"),
                    "firmware": self.parse_xml_field(root, "firmware_version"),
                    "design_name": self.parse_xml_field(root, "design/pretty_name"),
                    "design_status": self.parse_xml_field(root, "design/state_pretty"),
                    "ip_address": self.parse_xml_field(root, "network_interfaces/network_interface/address"),
                    "mac_address": self.parse_xml_field(root, "network_interfaces/network_interface/mac_address"),
                    "uptime": self.parse_xml_field(root, "design/uptime"),
                    "serial_number": self._first_non_empty([
                        self.parse_xml_field(root, "serial_number"),
                        self.parse_xml_field(root, "serial_no"),
                        self.parse_xml_field(root, "device_serial_number"),
                        self.parse_xml_field(root, "device/serial_number"),
                        self.parse_xml_field(root, "device/serial_no"),
                    ]),
                })

                if not status.get("serial_number"):
                    status["serial_number"] = self._extract_serial_from_html(ip)
                if not status.get("serial_number") and self.config.get("use_selenium_serial", True):
                    status["serial_number"] = self._extract_serial_with_selenium(ip)
                if not status.get("serial_number"):
                    status["serial_number"] = status.get("mac_address")
                
                status["reachable"] = True
        except Exception as e:
            status["reachable"] = False
            status["error"] = str(e)
        
        return status
