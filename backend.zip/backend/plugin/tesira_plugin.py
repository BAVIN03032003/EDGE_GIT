"""
Manual Platform Plugin: TesiraPlugin
"""

import json
import re
import time

import paramiko

from .base import ManualPlatformPlugin


class TesiraPlugin(ManualPlatformPlugin):
    """Biamp Tesira monitoring plugin over SSH."""

    name = "tesira"
    display_name = "Biamp Tesira"
    description = "Biamp Tesira DSP devices via SSH"
    supports_display_id = False
    supports_port = False
    default_port = 22
    SUPPORTED_MODELS = [
        "TesiraFORTE",
        "TesiraFORTE X",
        "Tesira SERVER",
        "Tesira SERVER-IO",
        "TesiraLUX",
        "TesiraAMP",
        "Voltera",
    ]

    COMMANDS = {
        "list_audio_blocks": {"description": "List Tesira aliases / audio blocks", "params": []},
        "get_audio_level": {
            "description": "Get audio level for a tag/channel",
            "params": [{"name": "tag", "type": "str"}, {"name": "channel", "type": "str"}],
        },
        "set_audio_level": {
            "description": "Set audio level for a tag/channel",
            "params": [
                {"name": "tag", "type": "str"},
                {"name": "channel", "type": "str"},
                {"name": "value_db", "type": "str"},
            ],
        },
        "mute_on": {
            "description": "Mute tag/channel",
            "params": [{"name": "tag", "type": "str"}, {"name": "channel", "type": "str"}],
        },
        "mute_off": {
            "description": "Unmute tag/channel",
            "params": [{"name": "tag", "type": "str"}, {"name": "channel", "type": "str"}],
        },
        "recall_preset": {
            "description": "Recall device preset",
            "params": [{"name": "preset_number", "type": "str"}],
        },
        "reboot": {"description": "Reboot device", "params": []},
        "start_audio": {"description": "Start audio", "params": []},
        "stop_audio": {"description": "Stop audio", "params": []},
        "raw_command": {"description": "Send raw Tesira command", "params": [{"name": "command", "type": "str"}]},
    }
    QUERY_COMMANDS = {
        "device_info": "get_device_info",
        "audio_blocks": "list_audio_blocks",
    }

    def _parse_value(self, response, key):
        if not response:
            return None

        match = re.search(rf'"{re.escape(key)}":"([^"]+)"', response)
        if match:
            return match.group(1)

        match = re.search(rf'"{re.escape(key)}":([^\s"{{}},]+)', response)
        if match:
            return match.group(1)

        return None

    def _send_command(self, shell, command, delay=1.5):
        shell.send(command + "\n")
        time.sleep(delay)

        output = ""
        while shell.recv_ready():
            output += shell.recv(65535).decode(errors="ignore")

        output = output.replace(command, "")
        return re.sub(r"[^\x20-\x7E\r\n]", "", output).strip()

    def _connect(self, ip, port, username, password):
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(
            hostname=ip,
            port=port,
            username=username,
            password=password,
            timeout=self.timeout,
            look_for_keys=False,
            allow_agent=False,
        )

        shell = ssh.invoke_shell()
        time.sleep(2.0)
        if shell.recv_ready():
            shell.recv(65535)
        return ssh, shell

    def _credentials(self):
        username = self.config.get("username")
        password = self.config.get("password")
        if not username or not password:
            raise ValueError("Missing credentials: username and password are required.")
        return username, password

    def _with_shell(self, ip, port, fn):
        username, password = self._credentials()
        ssh = None
        shell = None
        try:
            ssh, shell = self._connect(ip, port, username, password)
            return fn(shell)
        finally:
            try:
                if shell:
                    shell.close()
            except Exception:
                pass
            try:
                if ssh:
                    ssh.close()
            except Exception:
                pass

    def _decode_command(self, command):
        if isinstance(command, dict):
            return command.get("action"), command.get("params") or {}
        if isinstance(command, str):
            stripped = command.strip()
            if stripped.startswith("{") and stripped.endswith("}"):
                try:
                    parsed = json.loads(stripped)
                    if isinstance(parsed, dict):
                        return parsed.get("action"), parsed.get("params") or {}
                except Exception:
                    pass
            return stripped, {}
        return None, {}

    def _infer_model_from_hostname(self, hostname):
        host = hostname or ""
        patterns = [
            (r"TesiraForteX", "TesiraFORTE X"),
            (r"TesiraForte(?!X)", "TesiraFORTE"),
            (r"TesiraServerIO", "Tesira SERVER-IO"),
            (r"TesiraServer(?!IO)", "Tesira SERVER"),
            (r"TesiraLUX", "TesiraLUX"),
            (r"Voltera", "Voltera"),
            (r"TesiraAMP", "TesiraAMP"),
        ]
        for pattern, model in patterns:
            if re.search(pattern, host, re.IGNORECASE):
                return model
        return None

    def _get_device_model(self, shell, hostname, firmware):
        try:
            major_version = int(str(firmware or "").split(".")[0])
        except (TypeError, ValueError):
            major_version = 0

        if major_version >= 4:
            device_info = self._send_command(shell, "DEVICE get deviceInfo")
            model = self._parse_value(device_info, "deviceModel")
            if model:
                return model

        hostname_model = self._infer_model_from_hostname(hostname)
        if hostname_model:
            return hostname_model

        part = self._send_command(shell, "DEVICE get partNumber")
        part_number = self._parse_value(part, "value")
        if part_number:
            return part_number

        cleaned_hostname = re.sub(r"\d{6,}$", "", hostname or "").strip()
        if cleaned_hostname:
            return cleaned_hostname

        return f"Tesira Device (fw {firmware or 'N/A'})"

    def list_audio_blocks(self, ip, port=22):
        return self._with_shell(ip, port, lambda shell: self._send_command(shell, "SESSION get aliases"))

    def get_audio_level(self, ip, tag, channel, port=22):
        return self._with_shell(ip, port, lambda shell: self._send_command(shell, f"{tag} get level {channel}"))

    def set_audio_level(self, ip, tag, channel, value_db, port=22):
        return self._with_shell(ip, port, lambda shell: self._send_command(shell, f"{tag} set level {channel} {value_db}"))

    def mute_on(self, ip, tag, channel, port=22):
        return self._with_shell(ip, port, lambda shell: self._send_command(shell, f"{tag} set mute {channel} true"))

    def mute_off(self, ip, tag, channel, port=22):
        return self._with_shell(ip, port, lambda shell: self._send_command(shell, f"{tag} set mute {channel} false"))

    def recall_preset(self, ip, preset_number, port=22):
        return self._with_shell(ip, port, lambda shell: self._send_command(shell, f"DEVICE recallPreset {preset_number}"))

    def reboot(self, ip, port=22):
        return self._with_shell(ip, port, lambda shell: self._send_command(shell, "DEVICE reboot"))

    def start_audio(self, ip, port=22):
        return self._with_shell(ip, port, lambda shell: self._send_command(shell, "DEVICE startAudio"))

    def stop_audio(self, ip, port=22):
        return self._with_shell(ip, port, lambda shell: self._send_command(shell, "DEVICE stopAudio"))

    def get_device_info(self, ip, port=22, display_id=None):
        try:
            username, password = self._credentials()
        except ValueError as e:
            return {
                "ip_address": ip,
                "port": port,
                "display_id": display_id,
                "make": "Biamp",
                "device_type": "Tesira DSP",
                "current_status": "Offline",
                "error": str(e),
            }

        ssh = None
        shell = None

        try:
            ssh, shell = self._connect(ip, port, username, password)

            firmware = self._parse_value(self._send_command(shell, "DEVICE get version"), "value")
            serial = self._parse_value(self._send_command(shell, "DEVICE get serialNumber"), "value")
            hostname = self._parse_value(self._send_command(shell, "DEVICE get hostname"), "value")
            network = self._send_command(shell, "DEVICE get networkStatus")
            faults = self._send_command(shell, "DEVICE get activeFaultList")

            model = self._get_device_model(shell, hostname, firmware)
            mac = self._parse_value(network, "macAddress")
            device_ip = self._parse_value(network, "ip") or ip
            current_fault = self._parse_value(faults, "name")

            return {
                "ip_address": device_ip,
                "port": port,
                "display_id": display_id,
                "make": "Biamp",
                "device_type": "Tesira DSP",
                "device_name": hostname or model or "Biamp Tesira",
                "model": model,
                "serial_number": serial or mac,
                "firmware": firmware,
                "hostname": hostname,
                "mac_address": mac,
                "subnet_mask": self._parse_value(network, "netmask"),
                "gateway": self._parse_value(network, "gateway"),
                "default_gateway_status": self._parse_value(network, "defaultGatewayStatus"),
                "link_status": self._parse_value(network, "linkStatus"),
                "address_source": self._parse_value(network, "addressSource"),
                "telnet_enabled": self._parse_value(network, "telnetDisabled") == "false",
                "ssh_enabled": self._parse_value(network, "sshDisabled") == "false",
                "mdns_enabled": self._parse_value(network, "mDNSEnabled") == "true",
                "fault_status": "No Faults" if current_fault == "No fault" else (current_fault or "Unknown"),
                "current_status": "Online",
                "raw_network": network,
                "raw_faults": faults,
                "raw_audio_blocks": self._send_command(shell, "SESSION get aliases"),
            }
        except Exception as e:
            return {
                "ip_address": ip,
                "port": port,
                "display_id": display_id,
                "make": "Biamp",
                "device_type": "Tesira DSP",
                "current_status": "Offline",
                "error": str(e),
            }
        finally:
            try:
                if shell:
                    shell.close()
            except Exception:
                pass
            try:
                if ssh:
                    ssh.close()
            except Exception:
                pass

    def send_command(self, ip, port, display_id, command):
        try:
            action, params = self._decode_command(command)
            params = params or {}
            target_port = int(port or self.default_port)

            if action == "raw_command":
                tcp_command = params.get("command")
                if not tcp_command:
                    return False, "raw_command requires params.command"
                return True, self._with_shell(ip, target_port, lambda shell: self._send_command(shell, tcp_command))

            actions = {
                "list_audio_blocks": lambda: self.list_audio_blocks(ip, target_port),
                "get_audio_level": lambda: self.get_audio_level(ip, params.get("tag"), params.get("channel"), target_port),
                "set_audio_level": lambda: self.set_audio_level(ip, params.get("tag"), params.get("channel"), params.get("value_db"), target_port),
                "mute_on": lambda: self.mute_on(ip, params.get("tag"), params.get("channel"), target_port),
                "mute_off": lambda: self.mute_off(ip, params.get("tag"), params.get("channel"), target_port),
                "recall_preset": lambda: self.recall_preset(ip, params.get("preset_number"), target_port),
                "reboot": lambda: self.reboot(ip, target_port),
                "start_audio": lambda: self.start_audio(ip, target_port),
                "stop_audio": lambda: self.stop_audio(ip, target_port),
            }

            if action not in actions:
                return False, f"Unknown command: {action}"

            if action in {"get_audio_level", "set_audio_level", "mute_on", "mute_off"}:
                if not params.get("tag") or not params.get("channel"):
                    return False, f"{action} requires params.tag and params.channel"
            if action == "set_audio_level" and params.get("value_db") in (None, ""):
                return False, "set_audio_level requires params.value_db"
            if action == "recall_preset" and params.get("preset_number") in (None, ""):
                return False, "recall_preset requires params.preset_number"

            return True, actions[action]()
        except Exception as e:
            return False, str(e)

    def query_status(self, ip, port=22, display_id=None):
        info = self.get_device_info(ip, port, display_id)
        return {
            "reachable": info.get("current_status") == "Online",
            "device_name": info.get("device_name"),
            "model": info.get("model"),
            "serial_number": info.get("serial_number"),
            "firmware": info.get("firmware"),
            "fault_status": info.get("fault_status"),
            "error": info.get("error"),
        }
