"""
Manual Platform Plugin: ShureMXA920Plugin
"""

import requests
import urllib3

from .base import ManualPlatformPlugin

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class ShureMXA920Plugin(ManualPlatformPlugin):
    """Shure MXA series plugin via local REST API."""

    name = "shure_mxa920"
    display_name = "Shure MXA Series"
    description = "Shure MXA920/MXA910/MXA902/MXA710 devices"
    supports_display_id = False
    supports_port = False
    default_port = 443
    SUPPORTED_MODELS = ["MXA920", "MXA910", "MXA902", "MXA710"]

    COMMANDS = {}
    QUERY_COMMANDS = {}

    def _session(self):
        session = requests.Session()
        session.verify = False
        session.headers.update({
            "Accept": "application/json",
            "Content-Type": "application/json",
        })
        username = self.config.get("username")
        password = self.config.get("password")
        if username and password:
            session.auth = (username, password)
        return session

    def _base_url(self, ip, port):
        return f"https://{ip}:{port}/api/v1"

    def _parse_device_node(self, node):
        hw = node.get("hardwareIdentity", {}) if isinstance(node, dict) else {}
        sw = node.get("softwareIdentity", {}) if isinstance(node, dict) else {}
        com = node.get("communicationProtocol", {}) if isinstance(node, dict) else {}
        return {
            "device_id": hw.get("deviceId") or "",
            "serial_number": hw.get("serialNumber") or "",
            "model": sw.get("model") or "",
            "firmware": sw.get("firmwareVersion") or "",
            "firmware_valid": sw.get("firmwareValid", True),
            "device_state": node.get("deviceState") if isinstance(node, dict) else None,
            "compatibility": node.get("compatibility") if isinstance(node, dict) else None,
            "ip_address": com.get("address") or "",
            "capabilities": node.get("capabilities") or [],
        }

    def get_device_info(self, ip, port=443, display_id=None):
        session = self._session()
        try:
            devices_url = f"{self._base_url(ip, port)}/devices"
            resp = session.get(devices_url, timeout=self.timeout)
            if resp.status_code in (401, 403):
                return {
                    "ip_address": ip,
                    "port": port,
                    "display_id": display_id,
                    "make": "Shure",
                    "device_type": "Shure MXA",
                    "current_status": "Offline",
                    "error": "Invalid username or password."
                }
            resp.raise_for_status()
            data = resp.json() if resp.content else {}

            edges = data.get("edges", [])
            if not edges:
                return {
                    "ip_address": ip,
                    "port": port,
                    "display_id": display_id,
                    "make": "Shure",
                    "device_type": "Shure MXA",
                    "current_status": "Offline",
                    "error": "No devices found on this IP."
                }

            node = edges[0].get("node", {}) if isinstance(edges[0], dict) else {}
            device = self._parse_device_node(node)
            device_id = device.get("device_id")

            muted = None
            if device_id:
                try:
                    mute_url = f"{self._base_url(ip, port)}/devices/{device_id}/audio/mute"
                    mute_resp = session.get(mute_url, timeout=self.timeout)
                    if mute_resp.ok and mute_resp.content:
                        mute_json = mute_resp.json()
                        muted = mute_json.get("mute")
                except Exception:
                    muted = None

            return {
                "ip_address": ip,
                "port": port,
                "display_id": display_id,
                "make": "Shure",
                "device_name": device.get("device_name") or "Shure MXA Device",
                "model": device.get("model"),
                "serial_number": device.get("serial_number"),
                "firmware": device.get("firmware"),
                "mac_address": device.get("device_id"),
                "device_id": device.get("device_id"),
                "device_state": device.get("device_state"),
                "compatibility": device.get("compatibility"),
                "capabilities": device.get("capabilities"),
                "muted": muted,
                "device_type": "Shure MXA",
                "current_status": "Online",
                "raw_data": device
            }
        except Exception as e:
            return {
                "ip_address": ip,
                "port": port,
                "display_id": display_id,
                "make": "Shure",
                "device_type": "Shure MXA",
                "current_status": "Offline",
                "error": str(e)
            }
        finally:
            try:
                session.close()
            except Exception:
                pass

    def send_command(self, ip, port, display_id, command):
        return False, "Shure MXA plugin is monitoring-only."

    def query_status(self, ip, port=443, display_id=None):
        info = self.get_device_info(ip, port, display_id)
        return {
            "reachable": info.get("current_status") == "Online",
            "device_name": info.get("device_name"),
            "model": info.get("model"),
            "serial_number": info.get("serial_number"),
            "firmware": info.get("firmware"),
            "muted": info.get("muted"),
            "error": info.get("error")
        }
