"""
Manual Platform Plugin: CiscoRoomOSPlugin
"""

import socket
import json
import threading
import time
import re
import asyncio
import subprocess
import platform
import requests
import xml.etree.ElementTree as ET

from .base import ManualPlatformPlugin


class CiscoRoomOSPlugin(ManualPlatformPlugin):
    """Cisco RoomOS (Room Bar Pro etc.) via XML status endpoint."""

    name = "cisco_roomos"
    display_name = "Cisco RoomOS"
    description = "Cisco Room Bar Pro / RoomOS via SSH"
    supports_display_id = False
    supports_port = False
    default_port = 22
    SUPPORTED_MODELS = ["Room Bar Pro", "Room Bar", "Room Kit"]

    COMMANDS = {}
    QUERY_COMMANDS = {}

    def _safe_text(self, root, path):
        elem = root.find(path)
        return elem.text.strip() if elem is not None and elem.text else None

    def _parse_connected_devices(self, root):
        devices = []
        for dev in root.findall(".//Peripherals/ConnectedDevice"):
            devices.append({
                "Name": self._safe_text(dev, "Name"),
                "Type": self._safe_text(dev, "Type"),
                "Model": self._safe_text(dev, "Model"),
                "SerialNumber": self._safe_text(dev, "SerialNumber"),
                "Status": self._safe_text(dev, "Status"),
                "IPAddress": self._safe_text(dev, "NetworkAddress"),
                "Software": self._safe_text(dev, "SoftwareInfo"),
                "HardwareInfo": self._safe_text(dev, "HardwareInfo"),
                "DRAM": self._safe_text(dev, "DRAM"),
            })
        return devices

    def _parse_xml_to_device_info(self, root, ip, port, username):
        device_name = self._safe_text(root, ".//SystemUnit/ProductPlatform")
        model = self._safe_text(root, ".//SystemUnit/ProductId")
        firmware = self._safe_text(root, ".//SystemUnit/Software/Version")
        serial = self._safe_text(root, ".//SystemUnit/Hardware/Module/SerialNumber")
        mac = self._safe_text(root, ".//Network/Ethernet/MacAddress")

        periperals = self._parse_connected_devices(root)

        return {
            "ip_address": ip,
            "port": port,
            "display_id": None,
            "make": "Cisco",
            "device_type": "Cisco RoomOS",
            "device_name": device_name or model or "Cisco RoomOS",
            "model": model,
            "serial_number": serial or mac,
            "firmware": firmware,
            "software_release_date": self._safe_text(root, ".//SystemUnit/Software/ReleaseDate"),
            "display_name": self._safe_text(root, ".//SystemUnit/Software/DisplayName"),
            "udi": self._safe_text(root, ".//SystemUnit/Hardware/UDI"),
            "broadcast_name": self._safe_text(root, ".//SystemUnit/BroadcastName"),
            "mac_address": mac,
            "gateway": self._safe_text(root, ".//Network/IPv4/Gateway"),
            "subnet_mask": self._safe_text(root, ".//Network/IPv4/SubnetMask"),
            "current_status": "Online",
            "http_username": username,
            "periperals": periperals,
            "peripherals": periperals
        }

    def _fetch_status_xml(self, ip, username, password):
        from requests.auth import HTTPBasicAuth

        urls = [f"http://{ip}/status.xml", f"https://{ip}/status.xml"]
        last_error = None

        for url in urls:
            try:
                response = requests.get(
                    url,
                    auth=HTTPBasicAuth(username, password),
                    timeout=10,
                    verify=False
                )
                response.raise_for_status()
                root = ET.fromstring(response.content)
                return root, None
            except Exception as e:
                last_error = str(e)

        return None, last_error or "Unable to fetch status.xml"

    def get_device_info(self, ip, port=22, display_id=None):
        username = self.config.get("username")
        password = self.config.get("password")

        if not username or not password:
            return {
                "ip_address": ip,
                "port": port,
                "display_id": display_id,
                "make": "Cisco",
                "device_type": "Cisco RoomOS",
                "current_status": "Offline",
                "error": "Missing credentials: username and password are required."
            }

        root, error = self._fetch_status_xml(ip, username, password)
        if error:
            return {
                "ip_address": ip,
                "port": port,
                "display_id": display_id,
                "make": "Cisco",
                "device_type": "Cisco RoomOS",
                "current_status": "Offline",
                "error": error
            }

        return self._parse_xml_to_device_info(root, ip, port, username)

    def send_command(self, ip, port, display_id, command):
        return False, "Cisco RoomOS plugin is monitoring-only."

    def query_status(self, ip, port=22, display_id=None):
        info = self.get_device_info(ip, port, display_id)
        return {
            "reachable": info.get("current_status") == "Online",
            "device_name": info.get("device_name"),
            "model": info.get("model"),
            "serial_number": info.get("serial_number"),
            "firmware": info.get("firmware"),
            "error": info.get("error")
        }
