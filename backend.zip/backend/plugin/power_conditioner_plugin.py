import asyncio
import json
import platform
import re
import socket
import subprocess
import threading
import time
import xml.etree.ElementTree as ET

import requests

from .base import ManualPlatformPlugin

class PowerConditionerPlugin(ManualPlatformPlugin):
    """Power Conditioner plugin via HTTP API."""

    name = "power_conditioner"
    display_name = "Power Conditioner"
    description = "Power Conditioner (HTTP API via Edge)"
    supports_display_id = False
    supports_port = True
    default_port = 5000

    def _fetch_statistical_report(self, ip, port, headers):
        endpoints = [
            f"http://{ip}:{port}/powerconditioner/statistical-report",
            f"http://{ip}:{port}/statistical_report",
        ]

        last_error = None
        for url in endpoints:
            try:
                response = requests.get(url, headers=headers, timeout=self.timeout)
                response.raise_for_status()
                return response.json()
            except Exception as e:
                last_error = e

        if last_error:
            raise last_error
        raise RuntimeError("Unable to fetch statistical report")

    def _fetch_outlet_status(self, ip, port, headers):
        url = f"http://{ip}:{port}/powerconditioner/outlet-status"
        response = requests.get(url, headers=headers, timeout=self.timeout)
        response.raise_for_status()
        return response.json()

    def get_device_info(self, ip, port=5000, display_id=None):
        port = int(port or self.default_port)
        serial = (
            self.config.get("serial_number")
            or self.config.get("serial")
            or self.config.get("x_api_key")
        )
        headers = {"x-api-key": serial} if serial else {}

        info = {
            "ip_address": ip,
            "port": port,
            "serial_number": serial,
            "make": "Vector",
            "model": "Power Conditioner",
            "statistical_report": {},
            "outlet_status": {},
        }

        stat_error = None
        outlet_error = None

        try:
            info["statistical_report"] = self._fetch_statistical_report(ip, port, headers)
        except Exception as e:
            stat_error = str(e)

        try:
            info["outlet_status"] = self._fetch_outlet_status(ip, port, headers)
        except Exception as e:
            outlet_error = str(e)

        if stat_error:
            info["statistical_report_error"] = stat_error
        if outlet_error:
            info["outlet_status_error"] = outlet_error

        stat = info.get("statistical_report")
        if isinstance(stat, dict):
            if stat.get("hostname"):
                info["hostname"] = stat.get("hostname")
            if stat.get("firmware_version"):
                info["firmware_version"] = stat.get("firmware_version")
            if stat.get("mac_address"):
                info["mac_address"] = stat.get("mac_address")
            if stat.get("model"):
                info["model"] = stat.get("model")

        info["current_status"] = "Online" if (info.get("statistical_report") or info.get("outlet_status")) else "Offline"
        return info

    def send_command(self, ip, port, display_id, command):
        return False, "Power Conditioner control not supported via this plugin."
#power
    def query_status(self, ip, port=5000, display_id=None):
        return {
            "reachable": None,
            "current_status": "Unknown",
        }
