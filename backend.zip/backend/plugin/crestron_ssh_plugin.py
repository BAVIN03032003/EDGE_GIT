"""
Manual Platform Plugin: CrestronSSHPlugin
"""

import socket
import json
import threading
import time
import re
import asyncio
import subprocess
import platform
import requests
import xml.etree.ElementTree as ET

from .base import ManualPlatformPlugin


class CrestronSSHPlugin(ManualPlatformPlugin):
    """Crestron CP4N / AM-3200 via authenticated Crestron web API."""

    name = "crestron_ssh"
    display_name = "Control & Collaboration Systems"
    description = "Crestron CP4N and AM-3200 via Crestron web API"
    supports_display_id = False
    supports_port = False
    default_port = 22
    SUPPORTED_MODELS = [
        "CP4N",
        "AM-3200",
        "DM NVX",
        "DM NAX",
        "HD-HDNXM (Switchers)",
        "HD-PS (Presentation)",
        "4 Series (Control)",
        "Air Media (Wireless)",
    ]

    COMMANDS = {}
    QUERY_COMMANDS = {}

    def _normalize_mac(self, raw_mac):
        if not raw_mac:
            return None
        raw_value = str(raw_mac).strip()
        if raw_value.startswith("<") and raw_value.endswith(">"):
            return None
        cleaned = re.sub(r"[^0-9A-Fa-f]", "", str(raw_mac))
        if len(cleaned) < 12:
            return str(raw_mac).replace(".", ":")
        cleaned = cleaned[:12]
        return ":".join(cleaned[i:i+2] for i in range(0, 12, 2)).lower()

    def _clean_value(self, value):
        if value is None:
            return None
        value = str(value).strip()
        if not value:
            return None
        if value.startswith("<") and value.endswith(">"):
            return None
        return value

    def _crestron_login(self, ip, username, password):
        base_url = f"https://{ip}"
        login_url = f"{base_url}/userlogin.html"
        session = requests.Session()
        session.verify = False

        headers = {"User-Agent": "Mozilla/5.0"}
        r = session.get(login_url, headers=headers, timeout=8)
        trackid = session.cookies.get("TRACKID")
        if not trackid:
            raise Exception("TRACKID not found on login page")

        login_headers = {
            "Cookie": f"TRACKID={trackid}",
            "Origin": base_url,
            "Referer": login_url,
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": "Mozilla/5.0"
        }
        payload = {"login": username, "passwd": password}
        r2 = session.post(login_url, headers=login_headers, data=payload, timeout=10)
        if r2.status_code != 200:
            raise Exception(f"Login failed (HTTP {r2.status_code})")

        xsrf = r2.headers.get("CREST-XSRF-TOKEN")
        if xsrf:
            session.headers.update({"CREST-XSRF-TOKEN": xsrf})

        return session

    def _fetch_json(self, session, ip, path):
        url = f"https://{ip}{path}"
        resp = session.get(url, timeout=8)
        resp.raise_for_status()
        return resp.json()

    def _extract(self, text, pattern):
        m = re.search(pattern, text, re.IGNORECASE)
        return m.group(1).strip() if m else None

    def get_device_info(self, ip, port=22, display_id=None):
        username = self.config.get("username")
        password = self.config.get("password")

        if not username or not password:
            return {
                "ip_address": ip,
                "port": port,
                "display_id": display_id,
                "make": "Crestron",
                "device_type": "Crestron Device",
                "current_status": "Offline",
                "error": "Missing credentials: username and password are required."
            }

        try:
            session = self._crestron_login(ip, username, password)
            info_payload = self._fetch_json(session, ip, "/Device/DeviceInfo")
            device_info = ((info_payload or {}).get("Device") or {}).get("DeviceInfo") or {}
        except Exception as e:
            return {
                "ip_address": ip,
                "port": port,
                "display_id": display_id,
                "make": "Crestron",
                "device_type": "Crestron Device",
                "current_status": "Offline",
                "error": str(e)
            }
        finally:
            try:
                session.close()
            except Exception:
                pass

        model = device_info.get("Model")
        device_name = device_info.get("Name") or model or "Crestron Device"
        serial = self._clean_value(device_info.get("SerialNumber"))
        mac = self._normalize_mac(device_info.get("MacAddress") or device_info.get("DeviceId"))
        firmware = self._clean_value(device_info.get("DeviceVersion")) or self._clean_value(device_info.get("Version"))
        device_type = "Crestron Device"
        if model and "cp4n" in model.lower():
            device_type = "Crestron CP4N"
        elif model and "am-3200" in model.lower():
            device_type = "Crestron AM-3200"

        return {
            "ip_address": ip,
            "port": port,
            "display_id": display_id,
            "make": device_info.get("Manufacturer", "Crestron"),
            "device_name": device_name,
            "model": model,
            "serial_number": serial or mac,
            "mac_address": mac,
            "firmware": firmware,
            "build_date": device_info.get("BuildDate"),
            "device_id": device_info.get("DeviceId"),
            "device_type": device_type,
            "category": device_info.get("Category"),
            "puf_version": device_info.get("PufVersion"),
            "reboot_reason": device_info.get("RebootReason"),
            "device_key": device_info.get("Devicekey"),
            "api_version": device_info.get("Version"),
            "current_status": "Online",
            "raw_data": info_payload
        }

    def send_command(self, ip, port, display_id, command):
        return False, "Control & Collaboration Systems plugin is "

    def query_status(self, ip, port=22, display_id=None):
        info = self.get_device_info(ip, port, display_id)
        return {
            "reachable": info.get("current_status") == "Online",
            "device_name": info.get("device_name"),
            "model": info.get("model"),
            "serial_number": info.get("serial_number"),
            "firmware": info.get("firmware"),
            "error": info.get("error")
        }
