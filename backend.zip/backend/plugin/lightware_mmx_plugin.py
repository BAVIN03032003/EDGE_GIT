"""
Manual Platform Plugin: LightwareMMXPlugin
"""

import socket
import time

from .base import ManualPlatformPlugin


class LightwareMMXPlugin(ManualPlatformPlugin):
    """Lightware MMX matrix devices via LW2 TCP."""

    name = "lightware_mmx"
    display_name = "MMX"
    description = "Lightware MMX series via LW2 TCP"
    supports_display_id = False
    supports_port = True
    default_port = 10001

    SUPPORTED_MODELS = [
        "MMX4x2-HDMI",
        "MMX4x2-HT200",
        "MMX4x2-HDMI-USB20-L",
    ]

    COMMANDS = {}
    QUERY_COMMANDS = {}

    # -------------------------------
    # 🔧 Common Cleaner
    # -------------------------------
    def _clean_lw2_value(self, value):
        if not value or not isinstance(value, str):
            return value

        clean = value.strip().strip("()")

        # Extract value if it's key=value
        if "=" in clean:
            _, clean = clean.split("=", 1)

        return clean.strip()

    def _extract_response_value(self, payload):
        if not isinstance(payload, dict):
            return None
        return self._clean_lw2_value(payload.get("response"))

    def _parse_lw2_info(self, response_text):
        parsed = {}
        if not response_text:
            return parsed

        for line in response_text.splitlines():
            clean = self._clean_lw2_value(line)

            if "=" not in clean:
                continue

            key, value = clean.split("=", 1)
            key = key.replace("pr /.", "").strip()
            parsed[key] = value.strip()

        return parsed

    # -------------------------------
    # 🔌 TCP Communication
    # -------------------------------
    def _send_lw2(self, ip, port, command, timeout=None):
        target_port = int(port or self.default_port)
        effective_timeout = timeout or self.timeout

        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.settimeout(effective_timeout)
                sock.connect((ip, target_port))
                sock.sendall(f"{{{command}}}\r\n".encode("ascii"))
                time.sleep(0.15)

                response = b""
                while True:
                    try:
                        chunk = sock.recv(4096)
                    except socket.timeout:
                        break

                    if not chunk:
                        break

                    response += chunk
                    decoded = response.decode("ascii", errors="ignore")

                    if "END)" in decoded or (
                        decoded.count("(") > 0 and decoded.endswith(")\r\n")
                    ):
                        break

            text = response.decode("ascii", errors="ignore").strip()

            return {
                "success": True,
                "command": command,
                "response": text,
            }

        except Exception as e:
            return {
                "success": False,
                "command": command,
                "error": str(e),
            }

    # -------------------------------
    # 📊 Device Info
    # -------------------------------
    def get_device_info(self, ip, port=10001, display_id=None):
        product_resp = self._send_lw2(ip, port, "i")

        if not product_resp.get("success"):
            return {
                "ip_address": ip,
                "port": port,
                "display_id": display_id,
                "make": "Lightware",
                "device_type": "Lightware MMX",
                "current_status": "Offline",
                "error": product_resp.get("error", "Connection failed"),
            }

        serial_resp = self._send_lw2(ip, port, "S")
        board_resp = self._send_lw2(ip, port, "IS")
        firmware_resp = self._send_lw2(ip, port, "F")
        label_resp = self._send_lw2(ip, port, "LABEL")
        health_resp = self._send_lw2(ip, port, "ST")
        protocol_resp = self._send_lw2(ip, port, "P_?")
        network_resp = self._send_lw2(ip, port, "IP_STAT=?")

        product_info = self._parse_lw2_info(self._extract_response_value(product_resp))
        firmware_info = self._parse_lw2_info(self._extract_response_value(firmware_resp))

        # Clean model
        raw_model = (
            product_info.get("ProductName")
            or product_info.get("Product type")
            or self._extract_response_value(product_resp)
            or self.display_name
        )

        model = self._clean_lw2_value(raw_model)
        if model and model.startswith("I:"):
            model = model.replace("I:", "").strip()

        # Clean serial
        serial = self._extract_response_value(serial_resp)
        if serial and serial.startswith("SN:"):
            serial = serial.replace("SN:", "").strip()

        # Clean firmware
        firmware = (
            firmware_info.get("FirmwareVersion")
            or firmware_info.get("Version")
            or self._extract_response_value(firmware_resp)
        )
        if firmware and firmware.startswith("FW:"):
            firmware = firmware.replace("FW:", "").strip()

        return {
            "ip_address": ip,
            "port": port,
            "display_id": display_id,
            "make": "Lightware",
            "device_type": "Lightware MMX",
            "device_name": self._extract_response_value(label_resp) or model,
            "model": model,
            "serial_number": serial,
            "firmware": firmware,
            "board": self._extract_response_value(board_resp),
            "health": self._extract_response_value(health_resp),
            "protocol": self._extract_response_value(protocol_resp),
            "network_status": self._extract_response_value(network_resp),
            "current_status": "Online",
            "raw_data": {
                "product": self._extract_response_value(product_resp),
                "serial": serial,
                "board": self._extract_response_value(board_resp),
                "firmware": firmware,
                "label": self._extract_response_value(label_resp),
                "health": self._extract_response_value(health_resp),
                "protocol": self._extract_response_value(protocol_resp),
                "network": self._extract_response_value(network_resp),
            },
        }

    # -------------------------------
    # 🎛 Commands
    # -------------------------------
    def send_command(self, ip, port, display_id, command):
        try:
            if command.startswith("switch_video:"):
                _, i, o = command.split(":")
                result = self._send_lw2(ip, port, f"{i}@{o} V")

            elif command.startswith("switch_audio:"):
                _, i, o = command.split(":")
                result = self._send_lw2(ip, port, f"{i}@{o} A")

            elif command.startswith("switch_av:"):
                _, i, o = command.split(":")
                result = self._send_lw2(ip, port, f"{i}@{o} AV")

            elif command == "reboot":
                result = self._send_lw2(ip, port, "RST")

            elif command == "factory_reset":
                result = self._send_lw2(ip, port, "FACTORY=ALL")

            elif command == "ping":
                result = self._send_lw2(ip, port, "PING")

            elif command.startswith("raw:"):
                result = self._send_lw2(ip, port, command.split(":", 1)[1])

            else:
                return False, "Unsupported command"

            return result.get("success", False), self._clean_lw2_value(
                result.get("response") or result.get("error")
            )

        except Exception as e:
            return False, str(e)

    # -------------------------------
    # 📡 Status
    # -------------------------------
    def query_status(self, ip, port=10001, display_id=None):
        video = self._send_lw2(ip, port, "VC V")
        audio = self._send_lw2(ip, port, "VC A")
        health = self._send_lw2(ip, port, "ST")

        return {
            "make": "Lightware",
            "model_family": "MMX",
            "reachable": video.get("success") or health.get("success"),
            "current_status": "Online"
            if (video.get("success") or health.get("success"))
            else "Offline",
            "video_route": self._extract_response_value(video),
            "audio_route": self._extract_response_value(audio),
            "health": self._extract_response_value(health),
            "error": video.get("error") or audio.get("error") or health.get("error"),
        }