"""
Manual Platform Plugin: SamsungMDCPlugin
Samsung MDC Protocol Plugin for querying device info
"""
 
import socket
import json
import threading
import time
import re
import asyncio
import subprocess
import shutil
import platform
import requests
import xml.etree.ElementTree as ET
 
try:
    from .base import ManualPlatformPlugin as _BaseManualPlatformPlugin
except ImportError:
    _BaseManualPlatformPlugin = None
else:
    ManualPlatformPlugin = _BaseManualPlatformPlugin
 
 
class SamsungMDCPlugin(ManualPlatformPlugin):
    """Samsung MDC Protocol Plugin"""
   
    name = "samsung_mdc"
    display_name = "Samsung MDC"
    description = "Samsung MDC Display Control"
    supports_display_id = True
    supports_port = True
    default_port = 1515
   
    # MDC Command Codes
    CMD_SERIAL_NUMBER = 0x0B
    CMD_MODEL_NAME = 0x8A
    CMD_DEVICE_NAME = 0x67
    CMD_MODEL_NUMBER = 0x10
    CMD_FIRMWARE_VERSION = 0x0E
   
    # Commands: {key: (bytes, description)}
    COMMANDS = {
        "power_on": (b"\xAA\x11\xFE\x01\x01\x11", "Power ON"),
        "power_off": (b"\xAA\x11\xFE\x01\x00\x10", "Power OFF"),
        "hdmi_1": (b"\xAA\x14\xFE\x01\x23\x36", "HDMI 1"),
        "hdmi_2": (b"\xAA\x14\xFE\x01\x1E\x31", "HDMI 2"),
        "display_port": (b"\xAA\x14\xFE\x01\x0F\x22", "DisplayPort"),
        "dvi": (b"\xAA\x14\xFE\x01\x0C\x1F", "DVI"),
        "pc": (b"\xAA\x14\xFE\x01\x04\x17", "PC (RGB)"),
        "av": (b"\xAA\x14\xFE\x01\x08\x1B", "AV"),
        "volume_up": (b"\xAA\x12\xFE\x01\x01\x12", "Volume Up"),
        "volume_down": (b"\xAA\x12\xFE\x01\x00\x11", "Volume Down"),
        "mute_on": (b"\xAA\x13\xFE\x01\x01\x14", "Mute ON"),
        "mute_off": (b"\xAA\x13\xFE\x01\x00\x13", "Mute OFF"),
    }
   
    QUERY_COMMANDS = {
        "power": b"\xAA\x11\xFE\x00\x11",
        "input": b"\xAA\x14\xFE\x00\x14",
        "volume": b"\xAA\x12\xFE\x00\x12",
        "mute": b"\xAA\x13\xFE\x00\x13",
    }
   
    def _build_frame(self, cmd, device_id=0, data=None):
        """Build MDC frame"""
        if data is None:
            data = []
        payload = [cmd, device_id, len(data)] + list(data)
        checksum = sum(payload) & 0xFF
        return bytes([0xAA] + payload + [checksum])
   
    def _send_mdc(self, ip, port, frame, timeout=3):
        """Send MDC frame and receive response"""
        try:
            with socket.create_connection((ip, port), timeout=timeout) as sock:
                sock.sendall(frame)
                time.sleep(0.5)
                response = b""
                sock.settimeout(timeout)
                while True:
                    try:
                        chunk = sock.recv(256)
                        if not chunk:
                            break
                        response += chunk
                        if len(response) >= 5:
                            break
                    except socket.timeout:
                        break
                return response
        except Exception as e:
            return None
   
    def _get_data_bytes(self, response):
        """Parse response - extract data bytes"""
        if not response or len(response) < 7:
            return None
        if response[4] != 0x41:  # 0x41 = ACK
            return None
        return response[6:-1]  # strip header + checksum
   
    def _to_string(self, data):
        """Convert bytes to ASCII string"""
        if not data:
            return None
        return "".join(chr(b) for b in data if 32 <= b <= 126).strip()
   
    def get_device_info(self, ip, port=1515, display_id="00"):
        """Get device info via MDC protocol"""
        device_id = int(display_id, 16) if display_id else 0
       
        # Check if device is reachable (ping or TCP fallback)
        is_online = self._ping_host(ip, port)
        if not is_online:
            return {
                "ip_address": ip,
                "port": port,
                "display_id": display_id,
                "make": "Samsung",
                "model": "Samsung MDC Display",
                "serial_number": None,
                "device_name": None,
                "firmware_version": None,
                "mac_address": None,
                "current_status": "Offline",
                "error": "Device unreachable"
            }
       
        # Get MAC address
        mac = self._get_mac(ip)
       
        # Query device info via MDC
        info = {
            "ip_address": ip,
            "port": port,
            "display_id": display_id,
            "make": "Samsung",
            "current_status": "Online",
            "mac_address": mac,
        }
       
        try:
            # 1. Query Serial Number (CMD 0x0B)
            frame = self._build_frame(self.CMD_SERIAL_NUMBER, device_id)
            response = self._send_mdc(ip, port, frame)
            data = self._get_data_bytes(response)
            serial = self._to_string(data)
            if serial:
                info["serial_number"] = serial
           
            # 2. Query Model Name (CMD 0x8A)
            frame = self._build_frame(self.CMD_MODEL_NAME, device_id)
            response = self._send_mdc(ip, port, frame)
            data = self._get_data_bytes(response)
            model_name = self._to_string(data)
            if model_name:
                info["model"] = model_name
            else:
                info["model"] = "Samsung MDC Display"
           
            # 3. Query Device Name (CMD 0x67)
            frame = self._build_frame(self.CMD_DEVICE_NAME, device_id)
            response = self._send_mdc(ip, port, frame)
            data = self._get_data_bytes(response)
            device_name = self._to_string(data)
            if device_name:
                info["device_name"] = device_name
           
            # 4. Query Model Code / Model Number (CMD 0x10)
            # Returns: model_species, model_code, tv_tuner
            frame = self._build_frame(self.CMD_MODEL_NUMBER, device_id)
            response = self._send_mdc(ip, port, frame)
            data = self._get_data_bytes(response)
            if data and len(data) >= 3:
                info["model_species"] = f"0x{data[0]:02X}"
                info["model_code"] = f"0x{data[1]:02X}"
                info["tv_tuner"] = "Yes" if data[2] == 0x01 else "No"
           
            # 5. Query Firmware Version (CMD 0x0E)
            frame = self._build_frame(self.CMD_FIRMWARE_VERSION, device_id)
            response = self._send_mdc(ip, port, frame)
            data = self._get_data_bytes(response)
            firmware = self._to_string(data)
            if firmware:
                info["firmware_version"] = firmware
                info["firmware_current_version"] = firmware
       
        except Exception as e:
            info["error"] = str(e)
       
        return info
    def _ping_host(self, ip, port=None):
        """Ping host to check if online. Falls back to TCP connect if ping is unavailable."""
        try:
            if shutil.which("ping"):
                param = "-n" if platform.system().lower() == "windows" else "-c"
                result = subprocess.run(["ping", param, "1", ip], capture_output=True, timeout=3)
                if result.returncode == 0:
                    return True
        except Exception:
            pass

        probe_port = int(port) if port and int(port) > 0 else int(getattr(self, "default_port", 1515))
        try:
            with socket.create_connection((ip, probe_port), timeout=3):
                return True
        except Exception:
            return False

        probe_port = int(port) if port and int(port) > 0 else int(getattr(self, "default_port", 1515))
        try:
            with socket.create_connection((ip, probe_port), timeout=3):
                return True
        except Exception:
            return False
   
    def _get_mac(self, ip):
        """Get MAC address from ARP cache"""
        try:
            if platform.system().lower() == "windows":
                output = subprocess.check_output(["arp", "-a", ip], text=True, timeout=5)
                match = re.search(r"([0-9a-fA-F]{2}[-:]){5}[0-9a-fA-F]{2}", output)
            else:
                output = subprocess.check_output(["arp", "-n", ip], text=True, timeout=5)
                match = re.search(r"([0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}", output)
            return match.group(0).lower() if match else None
        except:
            return None
   
    def send_command(self, ip, port, display_id, command_key):
        """Send control command to device"""
        if command_key not in self.COMMANDS:
            return False, f"Unknown command: {command_key}"
       
        raw_bytes, label = self.COMMANDS[command_key]
       
        # Adjust display ID if needed
        device_id = int(display_id, 16) if display_id and display_id != "00" else 0
        if device_id != 0:
            raw_bytes = bytes([raw_bytes[0], device_id]) + raw_bytes[2:]
       
        try:
            sock = self.connect(ip, port)
            sock.sendall(raw_bytes)
           
            try:
                sock.settimeout(2)
                response = sock.recv(64)
                resp_hex = " ".join(f"{b:02X}" for b in response)
            except:
                resp_hex = None
           
            sock.close()
            return True, f"{label} - Response: {resp_hex or 'None'}"
        except Exception as e:
            return False, str(e)
   
    def query_status(self, ip, port=1515, display_id="00"):
        """Query device status"""
        device_id = int(display_id, 16) if display_id and display_id != "00" else 0
        status = {}
       
        for label, raw_bytes in self.QUERY_COMMANDS.items():
            # Adjust display ID
            cmd = bytes([raw_bytes[0], device_id]) + raw_bytes[2:] if device_id != 0 else raw_bytes
           
            try:
                sock = self.connect(ip, port)
                sock.sendall(cmd)
                sock.settimeout(3)
                response = sock.recv(64)
                sock.close()
               
                # Parse response
                if len(response) >= 6 and response[0] == 0xAA and response[1] == 0xFF:
                    data = response[6:-1] if len(response) > 7 else []
                   
                    if label == "power":
                        status["power"] = "ON" if (data[0] if data else 0) == 0x01 else "OFF"
                        status["is_powered_on"] = status["power"] == "ON"
                    elif label == "input":
                        input_map = {0x14: "HDMI 1", 0x1E: "HDMI 2", 0x0C: "DVI", 0x04: "PC", 0x08: "AV", 0x18: "DisplayPort"}
                        status["input"] = input_map.get(data[0] if data else 0, "Unknown")
                    elif label == "volume":
                        status["volume"] = data[0] if data else 0
                    elif label == "mute":
                        status["mute"] = "ON" if (data[0] if data else 0) == 0x01 else "OFF"
            except:
                pass
       
        return status