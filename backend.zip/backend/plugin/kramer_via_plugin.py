"""
Manual Platform Plugin: KramerVIAPlugin
"""

import socket
import json
import threading
import time
import re
import asyncio
import subprocess
import platform
import requests
import xml.etree.ElementTree as ET

from .base import ManualPlatformPlugin


class KramerVIAPlugin(ManualPlatformPlugin):
    """Kramer Connect 2 (VIA) plugin, IP-only discovery."""

    name = "kramer_via"
    display_name = "Kramer VIA"
    description = "Kramer Connect 2 (VIA) devices"
    supports_display_id = False
    supports_port = False
    default_port = 0
    SUPPORTED_MODELS = ["Connect 2 (VIA)"]

    COMMANDS = {}
    QUERY_COMMANDS = {}

    KRAMER_OUIS = {
        "00-1D-56",
        "00-0C-65",
        "00-13-89",
        "00-1D-57",
        "00-1D-58",
        "00-1D-59",
        "00-10-56",
        "F4-6A-DD",
    }

    def _ping_host(self, ip):
        param = "-n" if platform.system().lower() == "windows" else "-c"
        try:
            result = subprocess.run(["ping", param, "1", ip], capture_output=True, timeout=3)
            return result.returncode == 0
        except Exception:
            return False

    def _get_mac_address(self, ip): 
        try:
            if platform.system().lower() == "windows":
                output = subprocess.check_output(f"arp -a {ip}", shell=True, stderr=subprocess.DEVNULL, timeout=5).decode(errors="ignore")
            else:
                output = subprocess.check_output(["arp", "-n", ip], stderr=subprocess.DEVNULL, timeout=5).decode(errors="ignore")

            match = re.search(r"([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})", output, re.IGNORECASE)
            if match:
                return match.group(0).upper().replace(":", "-")
        except Exception:
            pass
        return "Unknown"

    def _get_vendor(self, mac_address):
        if mac_address and mac_address != "Unknown":
            prefix = mac_address[:8].upper()
            if prefix in self.KRAMER_OUIS:
                return "Kramer Electronics Ltd."
        return "Unknown Vendor"

    def _test_common_ports(self, ip):
        ports = [80, 443, 8080, 8000]
        open_ports = []
        for port in ports:
            try:
                with socket.create_connection((ip, port), timeout=1.5):
                    open_ports.append(port)
            except Exception:
                continue
        return open_ports

    def _clean_value(self, value):
        if not value:
            return None
        v = str(value).strip()
        v = re.sub(r"<[^>]+>", "", v)
        v = re.sub(r"&[a-z]+;", "", v)
        v = re.sub(r"[^\w\s\-\.\:]", "", v)
        if len(v) < 2:
            return None
        return v

    def _extract_page_details(self, content):
        details = {
            "serial_number": None,
            "model": None,
            "firmware": None,
            "hardware_version": None
        }
        # Common Kramer VIA page format: "Connect 2  Serial Number: 001D560AF8C3"
        combined = re.search(r"(Connect\s*2).*?Serial\s*Number[:\s]*([0-9A-Fa-f]{8,20})", content, re.IGNORECASE | re.DOTALL)
        if combined:
            details["model"] = "Connect 2 (VIA)"
            details["serial_number"] = combined.group(2).upper()

        patterns = {
            "serial_number": [r"Serial\s*Number[:\s]*([0-9A-Fa-f]{8,20})", r"SN[:\s]*([0-9A-Fa-f]{8,20})"],
            "model": [
                r"\b(Connect\s*2)\b",
                r"Model[:\s]*([^<\n\r]{3,60})",
                r"Product[:\s]*([^<\n\r]{3,60})"
            ],
            "firmware": [r"Firmware[:\s]*([^<\n\r]+)", r"Version[:\s]*([^<\n\r]+)"],
            "hardware_version": [r"Hardware[:\s]*([^<\n\r]+)", r"HW[:\s]*([^<\n\r]+)"],
        }
        for key, key_patterns in patterns.items():
            for pattern in key_patterns:
                matches = re.findall(pattern, content, re.IGNORECASE)
                for match in matches:
                    value = self._clean_value(match[0] if isinstance(match, tuple) else match)
                    if value:
                        details[key] = value
                        break
                if details[key]:
                    break
        return details

    def _fetch_web_info(self, ip):
        endpoints = ["/", "/index.html", "/status.html", "/api/system/info", "/api/device/info"]
        ports = [443, 80, 8080, 8000]
        details = {
            "serial_number": None,
            "model": None,
            "firmware": None,
            "hardware_version": None
        }
        for port in ports:
            for endpoint in endpoints:
                for _ in range(2):
                    try:
                        scheme = "https" if port == 443 else "http"
                        url = f"{scheme}://{ip}:{port}{endpoint}"
                        response = requests.get(url, timeout=5, verify=False, allow_redirects=True)
                        if response.status_code == 200:
                            parsed = self._extract_page_details(response.text)
                            for k in details:
                                if parsed.get(k):
                                    details[k] = parsed[k]
                            if sum(1 for v in details.values() if v) >= 2:
                                return details
                    except Exception:
                        pass
                    time.sleep(0.4)
        return details

    def get_device_info(self, ip, port=0, display_id=None):
        is_online = self._ping_host(ip)
        mac = self._get_mac_address(ip)
        vendor = self._get_vendor(mac)
        open_ports = self._test_common_ports(ip)
        web_details = self._fetch_web_info(ip)

        if open_ports or web_details.get("model") or web_details.get("serial_number"):
            is_online = True

        serial = web_details.get("serial_number")
        if not serial and mac != "Unknown":
            serial = re.sub(r"[^0-9A-Fa-f]", "", mac)

        model = web_details.get("model") or ("Connect 2 (VIA)" if ("Kramer" in vendor or 80 in open_ports or 443 in open_ports) else "Unknown")
        if model and "connect 2" in model.lower():
            model = "Connect 2 (VIA)"
        firmware = web_details.get("firmware")

        mac_suffix = re.sub(r"[^0-9A-Fa-f]", "", mac)[-6:] if mac != "Unknown" else "UNKNOWN"
        device_name = model if model and model != "Unknown" else f"Kramer Device {mac_suffix.upper()}"

        return {
            "ip_address": ip,
            "port": port,
            "display_id": display_id,
            "make": "Kramer",
            "device_name": device_name,
            "model": model,
            "serial_number": serial,
            "mac_address": mac if mac != "Unknown" else None,
            "firmware": firmware,
            "hardware_version": web_details.get("hardware_version"),
            "vendor": vendor,
            "open_ports": open_ports,
            "device_type": "Kramer VIA Device",
            "current_status": "Online" if is_online else "Offline"
        }

    def send_command(self, ip, port, display_id, command):
        return False, "Kramer VIA plugin is monitoring-only."

    def query_status(self, ip, port=0, display_id=None):
        online = self._ping_host(ip)
        return {"reachable": online, "status": "Online" if online else "Offline"}
