import socket
import time
import requests

from .base import ManualPlatformPlugin


class LightwarePlugin(ManualPlatformPlugin):

    name = "lightware"
    display_name = "UCX"
    description = "Lightware UCX family via LW3 and REST"
    supports_display_id = False
    supports_port = True
    default_port = 6107
    SUPPORTED_MODELS = [
        "UCX-2x1-HC30",
        "UCX-2x2-H30",
        "UCX-4x2-HC30",
        "UCX-4x2-HC30D",
        "UCX-2x1-HC40",
        "UCX-2x1-HC40-LCC",
        "UCX-2x2-H40",
        "UCX-2x2-H40-LCC",
        "UCX-4x2-HC40",
        "UCX-4x2-HC40-LCC",
        "UCX-4x2-HC40D",
        "UCX-4x2-HC40D-LCC",
        "UCX-4x3-HC40",
        "UCX-4x3-HC40-LCC",
        "UCX-4x3-HC40-BD",
        "UCX-4x3-HC40-BD-LCC",
    ]

    # ================= REST =================
    def _rest(self, ip, method, endpoint, data=None):
        url = f"http://{ip}/api{endpoint}"
        headers = {"Content-Type": "text/plain"}

        try:
            if method == "GET":
                r = requests.get(url, headers=headers, timeout=5)
            else:
                r = requests.post(url, data=data if data else "", headers=headers, timeout=5)

            return {
                "success": r.status_code == 200,
                "code": r.status_code,
                "response": r.text.strip()
            }

        except Exception as e:
            return {"success": False, "error": str(e)}

    # ================= LW3 =================
    def _lw3_info(self, ip):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            sock.connect((ip, 6107))

            sock.sendall(b"GET /.*\r\n")
            time.sleep(0.3)

            data = b""
            while True:
                try:
                    chunk = sock.recv(4096)
                    if not chunk:
                        break
                    data += chunk
                except socket.timeout:
                    break

            sock.close()

            parsed = {}
            for line in data.decode(errors="ignore").splitlines():
                if "=" in line:
                    key, val = line.split("=", 1)
                    key = key.replace("pr /.", "").strip()
                    parsed[key] = val.strip()

            return parsed

        except Exception as e:
            return {"error": str(e)}

    # ================= DEVICE INFO =================
    def get_device_info(self, ip, port=6107, display_id=None):
        lw3 = self._lw3_info(ip)
        if lw3.get("error"):
            return {
                "ip_address": ip,
                "port": port,
                "display_id": display_id,
                "make": "Lightware",
                "device_type": "Lightware UCX",
                "current_status": "Offline",
                "error": lw3.get("error")
            }

        hostname = self._rest(ip, "GET", "/V1/MANAGEMENT/NETWORK/Hostname")
        ip_addr = self._rest(ip, "GET", "/V1/MANAGEMENT/NETWORK/IpAddress")

        return {
            "ip_address": ip,
            "port": port,
            "display_id": display_id,
            "make": "Lightware",
            "device_type": "Lightware UCX",
            "device_name": hostname.get("response") or lw3.get("ProductName") or self.display_name,
            "model": lw3.get("ProductName"),
            "serial_number": lw3.get("SerialNumber"),
            "firmware": lw3.get("PackageVersion"),
            "hostname": hostname.get("response"),
            "ip": ip_addr.get("response"),
            "current_status": "Online"
        }

    # ================= COMMAND HANDLER =================
    def send_command(self, ip, port, display_id, command):

        try:
            # ---------- VIDEO ----------
            if command.startswith("switch:"):
                result = self._rest(ip, "POST", "/V1/MEDIA/VIDEO/XP/switch", command.split(":")[1])

            elif command.startswith("multi_switch:"):
                result = self._rest(ip, "POST", "/V1/MEDIA/VIDEO/XP/switch", command.split(":")[1])

            elif command.startswith("mute:"):
                _, inp, state = command.split(":")
                result = self._rest(ip, "POST", f"/V1/MEDIA/VIDEO/XP/I{inp}/Mute", state)

            # ---------- USB ----------
            elif command.startswith("dp_mode:"):
                _, port, mode = command.split(":")
                result = self._rest(ip, "POST", f"/V1/MEDIA/USB/U{port}/DpAltModePolicy", mode)

            elif command.startswith("restart_dp:"):
                inp = command.split(":")[1]
                result = self._rest(ip, "POST", f"/V1/MEDIA/VIDEO/I{inp}/DP/restartLinkTraining")

            # ---------- RS232 ----------
            elif command.startswith("rs232:"):
                cmd = command.split(":", 1)[1]
                result = self._rest(ip, "POST", "/V1/MEDIA/SERIAL/P1/send", cmd)

            # ---------- NETWORK ----------
            elif command == "get_network":
                return True, {
                    "hostname": self._rest(ip, "GET", "/V1/MANAGEMENT/NETWORK/Hostname"),
                    "ip": self._rest(ip, "GET", "/V1/MANAGEMENT/NETWORK/IpAddress"),
                    "dhcp": self._rest(ip, "GET", "/V1/MANAGEMENT/NETWORK/DhcpEnabled")
                }

            elif command == "enable_dhcp":
                self._rest(ip, "POST", "/V1/MANAGEMENT/NETWORK/DhcpEnabled", "true")
                result = self._rest(ip, "POST", "/V1/MANAGEMENT/NETWORK/applySettings")

            elif command == "disable_dhcp":
                self._rest(ip, "POST", "/V1/MANAGEMENT/NETWORK/DhcpEnabled", "false")
                result = self._rest(ip, "POST", "/V1/MANAGEMENT/NETWORK/applySettings")

            elif command.startswith("set_static_ip:"):
                _, ipaddr, subnet, gateway = command.split(":")

                self._rest(ip, "POST", "/V1/MANAGEMENT/NETWORK/DhcpEnabled", "false")
                self._rest(ip, "POST", "/V1/MANAGEMENT/NETWORK/StaticIpAddress", ipaddr)
                self._rest(ip, "POST", "/V1/MANAGEMENT/NETWORK/StaticSubnetMask", subnet)

                if gateway:
                    self._rest(ip, "POST", "/V1/MANAGEMENT/NETWORK/StaticGatewayAddress", gateway)

                result = self._rest(ip, "POST", "/V1/MANAGEMENT/NETWORK/applySettings")

            # ---------- SYSTEM ----------
            elif command == "reboot":
                result = self._rest(ip, "POST", "/V1/SYS/reboot")

            elif command == "factory_reset":
                result = self._rest(ip, "POST", "/V1/SYS/factoryDefaults")

            else:
                return False, "Unsupported command"

            return result.get("success", False), result.get("response") or result.get("error")

        except Exception as e:
            return False, str(e)

    # ================= STATUS =================
    def query_status(self, ip, port=6107, display_id=None):

        signal = self._rest(ip, "GET", "/V1/MEDIA/VIDEO/I1/SignalPresent")
        route = self._rest(ip, "GET", "/V1/MEDIA/VIDEO/XP/O1/ConnectedSource")

        return {
            "make": "Lightware",
            "model_family": "UCX",
            "reachable": signal.get("success"),
            "current_status": "Online" if signal.get("success") else "Offline",
            "signal_present": signal.get("response"),
            "route": route.get("response"),
            "error": signal.get("error") or route.get("error")
        }
