"""
Manual Platform Plugin: CrestronOccupancySensorPlugin
"""

import socket
import json
import threading
import time
import re
import asyncio
import subprocess
import platform
import requests
import xml.etree.ElementTree as ET

from .base import ManualPlatformPlugin


class CrestronOccupancySensorPlugin(ManualPlatformPlugin):
    """Crestron CEN-ODT-C-POE occupancy sensor via authenticated Crestron web API."""

    name = "crestron_occupancy_sensor"
    display_name = "Crestron Occupancy Sensor"
    description = "Crestron CEN-ODT-C-POE (IP + username + password)"
    supports_display_id = False
    supports_port = False
    default_port = 443
    SUPPORTED_MODELS = ["CEN-ODT-C-POE"]

    COMMANDS = {}
    QUERY_COMMANDS = {}

    def _normalize_mac(self, raw_mac):
        if not raw_mac:
            return None
        raw_value = str(raw_mac).strip()
        if raw_value.startswith("<") and raw_value.endswith(">"):
            return None
        cleaned = re.sub(r"[^0-9A-Fa-f]", "", str(raw_mac))
        if len(cleaned) < 12:
            return str(raw_mac).replace(".", ":")
        cleaned = cleaned[:12]
        return ":".join(cleaned[i:i+2] for i in range(0, 12, 2)).lower()

    def _clean_value(self, value):
        if value is None:
            return None
        value = str(value).strip()
        if not value:
            return None
        if value.startswith("<") and value.endswith(">"):
            return None
        return value

    def _crestron_login(self, ip, username, password):
        base_url = f"https://{ip}"
        login_url = f"{base_url}/userlogin.html"
        session = requests.Session()
        session.verify = False

        headers = {"User-Agent": "Mozilla/5.0"}
        r = session.get(login_url, headers=headers, timeout=8)
        trackid = session.cookies.get("TRACKID")
        if not trackid:
            raise Exception("TRACKID not found on login page")

        login_headers = {
            "Cookie": f"TRACKID={trackid}",
            "Origin": base_url,
            "Referer": login_url,
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": "Mozilla/5.0"
        }
        payload = {"login": username, "passwd": password}
        r2 = session.post(login_url, headers=login_headers, data=payload, timeout=10)
        if r2.status_code != 200:
            raise Exception(f"Login failed (HTTP {r2.status_code})")

        xsrf = r2.headers.get("CREST-XSRF-TOKEN")
        if xsrf:
            session.headers.update({"CREST-XSRF-TOKEN": xsrf})

        return session

    def _fetch_json(self, session, ip, path):
        url = f"https://{ip}{path}"
        resp = session.get(url, timeout=8)
        resp.raise_for_status()
        return resp.json()

    def get_device_info(self, ip, port=443, display_id=None):
        username = self.config.get("username")
        password = self.config.get("password")
        if not username or not password:
            return {
                "ip_address": ip,
                "port": port,
                "display_id": display_id,
                "make": "Crestron",
                "device_type": "Occupancy Sensor",
                "current_status": "Offline",
                "error": "Missing credentials: username and password are required."
            }

        session = None
        try:
            session = self._crestron_login(ip, username, password)
            info_payload = self._fetch_json(session, ip, "/Device/DeviceInfo")
            try:
                occ_payload = self._fetch_json(session, ip, "/Device/OccupancySensor/")
            except Exception:
                occ_payload = self._fetch_json(session, ip, "/Device/OccupancySensor")
        except Exception as e:
            return {
                "ip_address": ip,
                "port": port,
                "display_id": display_id,
                "make": "Crestron",
                "device_type": "Occupancy Sensor",
                "current_status": "Offline",
                "error": str(e)
            }
        finally:
            if session:
                try:
                    session.close()
                except Exception:
                    pass

        device_info = ((info_payload or {}).get("Device") or {}).get("DeviceInfo") or {}
        occupancy = ((occ_payload or {}).get("Device") or {}).get("OccupancySensor") or {}
        is_occupied = occupancy.get("IsRoomOccupied")

        return {
            "ip_address": ip,
            "port": port,
            "display_id": display_id,
            "make": device_info.get("Manufacturer", "Crestron"),
            "device_name": device_info.get("Name") or device_info.get("Model") or "Crestron Occupancy Sensor",
            "model": device_info.get("Model"),
            "serial_number": self._clean_value(device_info.get("SerialNumber")),
            "mac_address": self._normalize_mac(device_info.get("MacAddress") or device_info.get("DeviceId")),
            "firmware": self._clean_value(device_info.get("DeviceVersion")) or self._clean_value(device_info.get("Version")),
            "device_id": device_info.get("DeviceId"),
            "build_date": device_info.get("BuildDate"),
            "device_type": "Crestron Occupancy Sensor",
            "category": device_info.get("Category"),
            "puf_version": device_info.get("PufVersion"),
            "reboot_reason": device_info.get("RebootReason"),
            "device_key": device_info.get("Devicekey"),
            "api_version": device_info.get("Version"),
            "is_room_occupied": is_occupied,
            "is_grace_occupancy_detected": occupancy.get("IsGraceOccupancyDetected"),
            "timeout_seconds": occupancy.get("TimeoutSeconds"),
            "is_led_flash_enabled": occupancy.get("IsLedFlashEnabled"),
            "occupancy_sensor": occupancy,
            "raw_data": {
                "DeviceInfo": device_info,
                "OccupancySensor": occupancy
            },
            "current_status": "Online"
        }

    def send_command(self, ip, port, display_id, command):
        return False, "Crestron Occupancy Sensor plugin is monitoring-only."

    def query_status(self, ip, port=443, display_id=None):
        username = self.config.get("username")
        password = self.config.get("password")
        if not username or not password:
            return {"reachable": False, "error": "Missing credentials: username and password are required."}

        session = None
        try:
            session = self._crestron_login(ip, username, password)
            info_payload = self._fetch_json(session, ip, "/Device/DeviceInfo")
            try:
                occ_payload = self._fetch_json(session, ip, "/Device/OccupancySensor/")
            except Exception:
                occ_payload = self._fetch_json(session, ip, "/Device/OccupancySensor")
        except Exception as e:
            return {"reachable": False, "error": str(e)}
        finally:
            if session:
                try:
                    session.close()
                except Exception:
                    pass

        device_info = ((info_payload or {}).get("Device") or {}).get("DeviceInfo") or {}
        occupancy = ((occ_payload or {}).get("Device") or {}).get("OccupancySensor") or {}

        return {
            "reachable": True,
            "device_name": device_info.get("Name") or device_info.get("Model"),
            "model": device_info.get("Model"),
            "serial_number": device_info.get("SerialNumber"),
            "is_room_occupied": occupancy.get("IsRoomOccupied"),
            "is_grace_occupancy_detected": occupancy.get("IsGraceOccupancyDetected"),
            "timeout_seconds": occupancy.get("TimeoutSeconds"),
            "is_led_flash_enabled": occupancy.get("IsLedFlashEnabled"),
            "raw_occupancy": occupancy
        }
