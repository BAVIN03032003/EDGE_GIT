"""
Manual Platform Plugin: ShureMXA920Plugin
"""

import json
import socket
import time

from .base import ManualPlatformPlugin


class ShureMXA920Plugin(ManualPlatformPlugin):
    """Shure MXA920 TCP control plugin based on Shure command strings."""

    name = "shure_mxa920"
    display_name = "Shure MXA920"
    description = "Shure MXA920 microphone array via TCP control port"
    supports_display_id = False
    supports_port = False
    default_port = 2202
    SUPPORTED_MODELS = ["MXA920", "MXA910", "MXA902", "MXA710"]

    COMMANDS = {
        "device_mute": {"description": "Set device mute state", "params": [{"name": "state", "type": "str"}]},
        "identify": {"description": "Set identify flash", "params": [{"name": "state", "type": "str"}]},
        "auto_coverage": {"description": "Set auto coverage", "params": [{"name": "state", "type": "str"}]},
        "reboot": {"description": "Reboot the device", "params": []},
        "factory_reset": {"description": "Restore factory defaults", "params": []},
        "set_led_brightness": {"description": "Set LED brightness 0-5", "params": [{"name": "level", "type": "int"}]},
        "set_led_color_unmuted": {"description": "Set unmuted LED color", "params": [{"name": "color", "type": "str"}]},
        "set_led_color_muted": {"description": "Set muted LED color", "params": [{"name": "color", "type": "str"}]},
        "set_led_state_unmuted": {"description": "Set unmuted LED state", "params": [{"name": "state", "type": "str"}]},
        "set_led_state_muted": {"description": "Set muted LED state", "params": [{"name": "state", "type": "str"}]},
        "set_led_in_state": {"description": "Set LED-in state", "params": [{"name": "state", "type": "str"}]},
        "recall_preset": {"description": "Recall preset 1-10", "params": [{"name": "preset", "type": "int"}]},
        "set_channel_mute": {"description": "Set channel mute", "params": [{"name": "channel", "type": "int"}, {"name": "state", "type": "str"}]},
        "set_channel_gain_db": {"description": "Set channel gain in dB", "params": [{"name": "channel", "type": "int"}, {"name": "db", "type": "float"}]},
        "adjust_channel_gain_db": {"description": "Adjust channel gain by dB", "params": [{"name": "channel", "type": "int"}, {"name": "delta_db", "type": "float"}]},
        "reset_channel_gain": {"description": "Reset channel gain to 0 dB", "params": [{"name": "channel", "type": "int"}]},
        "set_postgate_mute": {"description": "Set postgate mute", "params": [{"name": "channel", "type": "int"}, {"name": "state", "type": "str"}]},
        "set_postgate_gain_db": {"description": "Set postgate gain in dB", "params": [{"name": "channel", "type": "int"}, {"name": "db", "type": "float"}]},
        "set_intellimix_bypass": {"description": "Set IntelliMix bypass", "params": [{"name": "state", "type": "str"}]},
        "set_eq_bypass": {"description": "Set EQ bypass", "params": [{"name": "state", "type": "str"}]},
        "set_eq_contour": {"description": "Set EQ contour", "params": [{"name": "state", "type": "str"}]},
        "set_channel_solo": {"description": "Set channel solo enable/disable", "params": [{"name": "channel", "type": "int"}, {"name": "state", "type": "str"}]},
        "set_channel_peq": {"description": "Set channel PEQ 0", "params": [{"name": "channel", "type": "int"}, {"name": "state", "type": "str"}]},
        "set_coverage_mute": {"description": "Set coverage area mute", "params": [{"name": "area", "type": "int"}, {"name": "state", "type": "str"}]},
        "set_coverage_gain_db": {"description": "Set coverage area gain in dB", "params": [{"name": "area", "type": "int"}, {"name": "db", "type": "float"}]},
        "adjust_coverage_gain_db": {"description": "Adjust coverage area gain by dB", "params": [{"name": "area", "type": "int"}, {"name": "delta_db", "type": "float"}]},
        "reset_coverage_gain": {"description": "Reset coverage area gain to 0 dB", "params": [{"name": "area", "type": "int"}]},
        "set_array_height": {"description": "Set array height in cm", "params": [{"name": "height_cm", "type": "int"}]},
        "set_lobe_width": {"description": "Set lobe width", "params": [{"name": "lobe", "type": "int"}, {"name": "width", "type": "str"}]},
        "set_lobe_x": {"description": "Set lobe X", "params": [{"name": "lobe", "type": "int"}, {"name": "value", "type": "int"}]},
        "set_lobe_y": {"description": "Set lobe Y", "params": [{"name": "lobe", "type": "int"}, {"name": "value", "type": "int"}]},
        "set_lobe_z": {"description": "Set lobe Z", "params": [{"name": "lobe", "type": "int"}, {"name": "value", "type": "int"}]},
        "raw_command": {"description": "Send raw TCP command", "params": [{"name": "command", "type": "str"}]},
    }

    QUERY_COMMANDS = {
        "device_info": "retrieve_device_info",
        "lights": "get_lights_status",
        "presets": "get_presets_status",
        "channels": "get_channels_status",
        "intellimix": "get_intellimix_status",
        "coverage": "get_coverage_status",
        "lobes": "get_lobe_status",
    }

    ALL_COLORS = [
        "RED", "ORANGE", "GOLD", "YELLOW", "YELLOWGREEN", "GREEN",
        "TURQUOISE", "POWDERBLUE", "CYAN", "SKYBLUE", "BLUE",
        "PURPLE", "LIGHTPURPLE", "VIOLET", "ORCHID", "PINK", "WHITE",
    ]
    LED_STATES = {"ON", "OFF", "FLASHING"}
    TOGGLE_STATES = {"ON", "OFF", "TOGGLE"}
    SOLO_STATES = {"ENABLE", "DISABLE"}
    PEQ_STATES = {"ON", "OFF", "TOGGLE"}
    LOBE_WIDTHS = {"NARROW", "MEDIUM", "WIDE"}

    def _resolve_port(self, port=None):
        # MXA920 TCP control is fixed on 2202. Ignore stale saved ports like 443.
        return int(self.default_port)

    def _send_tcp(self, ip, command, port=None, timeout=None):
        target_port = self._resolve_port(port)
        target_timeout = timeout or self.timeout or 3
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.settimeout(target_timeout)
                sock.connect((ip, target_port))
                sock.sendall(f"{command}\r\n".encode("ascii"))
                time.sleep(0.2)
                data = b""
                sock.settimeout(0.5)
                try:
                    while True:
                        chunk = sock.recv(4096)
                        if not chunk:
                            break
                        data += chunk
                except socket.timeout:
                    pass
                return data.decode("ascii", errors="ignore").strip()
        except Exception:
            return None

    def _parse(self, response, keyword):
        if not response or keyword not in response:
            return None
        tokens = response.split()
        for idx, token in enumerate(tokens):
            if keyword in token and idx + 1 < len(tokens):
                return self._clean(tokens[idx + 1])
        return None

    def _clean(self, value):
        if value is None:
            return None
        return str(value).strip(">").strip("<").strip("{").strip("}").strip('"').strip("'").strip()

    def _gain_to_db(self, raw):
        try:
            return round(int(raw) / 10.0 - 110.0, 1)
        except Exception:
            return None

    def _db_to_gain(self, db):
        return int((float(db) + 110.0) * 10)

    def _channel_id(self, number):
        return str(int(number)).zfill(2)

    def _toggle_state(self, state, allow_toggle=True):
        value = str(state or "").strip().upper()
        allowed = self.TOGGLE_STATES if allow_toggle else {"ON", "OFF"}
        if value not in allowed:
            raise ValueError(f"Invalid state '{state}'. Expected one of {sorted(allowed)}")
        return value

    def _send_ok(self, ip, command, port=None):
        response = self._send_tcp(ip, command, port=port)
        if not response:
            raise ValueError("No response from device.")
        return response

    def _current_channel_gain_db(self, ip, channel, port):
        ch = self._channel_id(channel)
        raw = self._query_value(ip, f"< GET {ch} AUDIO_GAIN_HI_RES >", "AUDIO_GAIN_HI_RES", port)
        return self._gain_to_db(raw) or 0

    def _current_coverage_gain_db(self, ip, area, port):
        ca = self._channel_id(area)
        raw = self._query_value(ip, f"< GET {ca} CA_GAIN >", "CA_GAIN", port)
        return self._gain_to_db(raw) or 0

    def _adjust_channel_gain(self, ip, channel, delta_db, port):
        current = self._current_channel_gain_db(ip, channel, port)
        ch = self._channel_id(channel)
        return self._send_ok(ip, f"< SET {ch} AUDIO_GAIN_HI_RES {self._db_to_gain(current + float(delta_db))} >", port)

    def _adjust_coverage_gain(self, ip, area, delta_db, port):
        current = self._current_coverage_gain_db(ip, area, port)
        ca = self._channel_id(area)
        return self._send_ok(ip, f"< SET {ca} CA_GAIN {self._db_to_gain(current + float(delta_db))} >", port)

    def _decode_command(self, command):
        if isinstance(command, dict):
            return command.get("action"), command.get("params") or {}
        if isinstance(command, str):
            stripped = command.strip()
            if stripped.startswith("{") and stripped.endswith("}"):
                try:
                    parsed = json.loads(stripped)
                    if isinstance(parsed, dict):
                        return parsed.get("action"), parsed.get("params") or {}
                except Exception:
                    pass
            return stripped, {}
        return None, {}

    def _query_value(self, ip, command, keyword, port=None):
        return self._parse(self._send_tcp(ip, command, port=port), keyword)

    def retrieve_device_info(self, ip, port=2202):
        port = self._resolve_port(port)
        info = {
            "ip_address": ip,
            "model": self._query_value(ip, "< GET MODEL >", "MODEL", port) or "N/A",
            "serial_number": self._query_value(ip, "< GET SERIAL_NUM >", "SERIAL_NUM", port) or "N/A",
            "firmware": self._query_value(ip, "< GET FW_VER >", "FW_VER", port) or "N/A",
            "device_id": self._query_value(ip, "< GET DEVICE_ID >", "DEVICE_ID", port) or "N/A",
            "dante_name": self._query_value(ip, "< GET NA_DEVICE_NAME >", "NA_DEVICE_NAME", port) or "N/A",
            "mac_address": self._query_value(ip, "< GET CONTROL_MAC_ADDR >", "CONTROL_MAC_ADDR", port) or "N/A",
            "ip_audio": self._query_value(ip, "< GET IP_ADDR_NET_AUDIO_PRIMARY >", "IP_ADDR_NET_AUDIO_PRIMARY", port) or "N/A",
            "subnet_mask": self._query_value(ip, "< GET IP_SUBNET_NET_AUDIO_PRIMARY >", "IP_SUBNET_NET_AUDIO_PRIMARY", port) or "N/A",
            "gateway": self._query_value(ip, "< GET IP_GATEWAY_NET_AUDIO_PRIMARY >", "IP_GATEWAY_NET_AUDIO_PRIMARY", port) or "N/A",
            "encryption": self._query_value(ip, "< GET ENCRYPTION >", "ENCRYPTION", port) or "N/A",
            "muted": self._query_value(ip, "< GET DEVICE_AUDIO_MUTE >", "DEVICE_AUDIO_MUTE", port) or "N/A",
            "auto_coverage": self._query_value(ip, "< GET AUTO_COVERAGE >", "AUTO_COVERAGE", port) or "N/A",
            "last_error": self._send_tcp(ip, "< GET LAST_ERROR_EVENT >", port=port) or "N/A",
        }
        return info

    def get_lights_status(self, ip, port=2202):
        port = self._resolve_port(port)
        return {
            "brightness": self._query_value(ip, "< GET LED_BRIGHTNESS >", "LED_BRIGHTNESS", port),
            "color_unmuted": self._query_value(ip, "< GET LED_COLOR_UNMUTED >", "LED_COLOR_UNMUTED", port),
            "state_unmuted": self._query_value(ip, "< GET LED_STATE_UNMUTED >", "LED_STATE_UNMUTED", port),
            "color_muted": self._query_value(ip, "< GET LED_COLOR_MUTED >", "LED_COLOR_MUTED", port),
            "state_muted": self._query_value(ip, "< GET LED_STATE_MUTED >", "LED_STATE_MUTED", port),
            "led_in_state": self._query_value(ip, "< GET DEV_LED_IN_STATE >", "DEV_LED_IN_STATE", port),
        }

    def get_presets_status(self, ip, port=2202):
        port = self._resolve_port(port)
        active = self._query_value(ip, "< GET PRESET >", "PRESET", port)
        presets = []
        for preset in range(1, 11):
            num = str(preset).zfill(2)
            response = self._send_tcp(ip, f"< GET PRESET_NAME {num} >", port=port)
            parts = response.split() if response else []
            name = parts[4] if len(parts) >= 5 else None
            if name in ("{empty}", ">", "<", None):
                name = None
            presets.append({
                "preset": preset,
                "name": name,
                "active": str(active) == str(preset),
            })
        return {"active_preset": active, "presets": presets}

    def get_channels_status(self, ip, port=2202):
        port = self._resolve_port(port)
        channels = []
        for number in range(1, 10):
            ch = self._channel_id(number)
            label = "Automix" if number == 9 else f"Ch {number}"
            gain_raw = self._query_value(ip, f"< GET {ch} AUDIO_GAIN_HI_RES >", "AUDIO_GAIN_HI_RES", port)
            channels.append({
                "channel": number,
                "name": self._query_value(ip, f"< GET {ch} CHAN_NAME >", "CHAN_NAME", port) or label,
                "gain_raw": gain_raw,
                "gain_db": self._gain_to_db(gain_raw),
                "muted": self._query_value(ip, f"< GET {ch} AUDIO_MUTE >", "AUDIO_MUTE", port),
                "rms": self._query_value(ip, f"< GET {ch} AUDIO_IN_RMS_LVL >", "AUDIO_IN_RMS_LVL", port),
                "clip": self._query_value(ip, f"< GET {ch} AUDIO_OUT_CLIP_INDICATOR >", "AUDIO_OUT_CLIP_INDICATOR", port),
            })
        return {"auto_coverage": self._query_value(ip, "< GET AUTO_COVERAGE >", "AUTO_COVERAGE", port), "channels": channels}

    def get_intellimix_status(self, ip, port=2202):
        port = self._resolve_port(port)
        channels = []
        for number in range(1, 9):
            ch = self._channel_id(number)
            channels.append({
                "channel": number,
                "solo": self._query_value(ip, f"< GET {ch} CHAN_AUTOMIX_SOLO_EN >", "CHAN_AUTOMIX_SOLO_EN", port),
                "gate": self._query_value(ip, f"< GET {ch} AUTOMIX_GATE_OUT_EXT_SIG >", "AUTOMIX_GATE_OUT_EXT_SIG", port),
                "peq": self._query_value(ip, f"< GET {ch} PEQ 0 >", "PEQ", port),
            })
        return {
            "bypass_imx": self._query_value(ip, "< GET BYPASS_IMX >", "BYPASS_IMX", port),
            "bypass_all_eq": self._query_value(ip, "< GET BYPASS_ALL_EQ >", "BYPASS_ALL_EQ", port),
            "eq_contour": self._query_value(ip, "< GET EQ_CONTOUR >", "EQ_CONTOUR", port),
            "num_active_mics": self._query_value(ip, "< GET NUM_ACTIVE_MICS >", "NUM_ACTIVE_MICS", port),
            "channels": channels,
        }

    def get_coverage_status(self, ip, port=2202):
        port = self._resolve_port(port)
        areas = []
        for number in range(1, 9):
            ca = self._channel_id(number)
            gain_raw = self._query_value(ip, f"< GET {ca} CA_GAIN >", "CA_GAIN", port)
            areas.append({
                "area": number,
                "mute": self._query_value(ip, f"< GET {ca} CA_MUTE >", "CA_MUTE", port),
                "gain_raw": gain_raw,
                "gain_db": self._gain_to_db(gain_raw),
                "gate": self._query_value(ip, f"< GET {ca} AUTOMIX_GATE_OUT_CA >", "AUTOMIX_GATE_OUT_CA", port),
            })
        return {"auto_coverage": self._query_value(ip, "< GET AUTO_COVERAGE >", "AUTO_COVERAGE", port), "areas": areas}

    def get_lobe_status(self, ip, port=2202):
        port = self._resolve_port(port)
        lobes = []
        for number in range(1, 9):
            ch = self._channel_id(number)
            lobes.append({
                "lobe": number,
                "width": self._query_value(ip, f"< GET {ch} BEAM_W >", "BEAM_W", port),
                "x": self._query_value(ip, f"< GET {ch} BEAM_X >", "BEAM_X", port),
                "y": self._query_value(ip, f"< GET {ch} BEAM_Y >", "BEAM_Y", port),
                "z": self._query_value(ip, f"< GET {ch} BEAM_Z >", "BEAM_Z", port),
            })
        return {"array_height": self._query_value(ip, "< GET ARRAY_HEIGHT >", "ARRAY_HEIGHT", port), "lobes": lobes}

    def get_device_info(self, ip, port=2202, display_id=None):
        try:
            port = self._resolve_port(port)
            model_probe = self._send_tcp(ip, "< GET MODEL >", port=port)
            if not model_probe:
                return {
                    "ip_address": ip,
                    "port": port,
                    "display_id": display_id,
                    "make": "Shure",
                    "device_type": "Shure MXA",
                    "current_status": "Offline",
                    "error": f"Cannot connect to {ip}:{port}",
                }

            device = self.retrieve_device_info(ip, port=port)
            return {
                "ip_address": ip,
                "port": port,
                "display_id": display_id,
                "make": "Shure",
                "device_type": "Shure MXA",
                "device_name": device.get("dante_name") or device.get("model") or "Shure MXA Device",
                "model": device.get("model"),
                "serial_number": device.get("serial_number"),
                "firmware": device.get("firmware"),
                "mac_address": device.get("mac_address"),
                "device_id": device.get("device_id"),
                "dante_name": device.get("dante_name"),
                "subnet_mask": device.get("subnet_mask"),
                "gateway": device.get("gateway"),
                "encryption": device.get("encryption"),
                "muted": device.get("muted"),
                "auto_coverage": device.get("auto_coverage"),
                "last_error": device.get("last_error"),
                "current_status": "Online",
                "raw_device_info": device,
                "raw_queries": {
                    "device_info": device,
                    "lights": self.get_lights_status(ip, port=port),
                    "presets": self.get_presets_status(ip, port=port),
                    "channels": self.get_channels_status(ip, port=port),
                    "intellimix": self.get_intellimix_status(ip, port=port),
                    "coverage": self.get_coverage_status(ip, port=port),
                    "lobes": self.get_lobe_status(ip, port=port),
                },
            }
        except Exception as e:
            return {
                "ip_address": ip,
                "port": port,
                "display_id": display_id,
                "make": "Shure",
                "device_type": "Shure MXA",
                "current_status": "Offline",
                "error": str(e),
            }

    def send_command(self, ip, port, display_id, command):
        try:
            action, params = self._decode_command(command)
            params = params or {}
            if not action:
                return False, "Missing command action."

            target_port = self._resolve_port(port)

            if action == "raw_command":
                tcp_command = params.get("command") or (command if isinstance(command, str) and command.strip().startswith("<") else None)
                if not tcp_command:
                    return False, "raw_command requires params.command"
                return True, self._send_ok(ip, tcp_command, port=target_port)

            actions = {
                "device_mute": lambda: self._send_ok(ip, f"< SET DEVICE_AUDIO_MUTE {self._toggle_state(params.get('state'))} >", target_port),
                "identify": lambda: self._send_ok(ip, f"< SET FLASH {self._toggle_state(params.get('state'), allow_toggle=False)} >", target_port),
                "auto_coverage": lambda: self._send_ok(ip, f"< SET AUTO_COVERAGE {self._toggle_state(params.get('state'), allow_toggle=False)} >", target_port),
                "reboot": lambda: self._send_ok(ip, "< SET REBOOT >", target_port),
                "factory_reset": lambda: self._send_ok(ip, "< SET DEFAULT_SETTINGS >", target_port),
                "set_led_brightness": lambda: self._send_ok(ip, f"< SET LED_BRIGHTNESS {int(params.get('level'))} >", target_port),
                "set_led_color_unmuted": lambda: self._send_ok(ip, f"< SET LED_COLOR_UNMUTED {str(params.get('color')).strip().upper()} >", target_port),
                "set_led_color_muted": lambda: self._send_ok(ip, f"< SET LED_COLOR_MUTED {str(params.get('color')).strip().upper()} >", target_port),
                "set_led_state_unmuted": lambda: self._send_ok(ip, f"< SET LED_STATE_UNMUTED {str(params.get('state')).strip().upper()} >", target_port),
                "set_led_state_muted": lambda: self._send_ok(ip, f"< SET LED_STATE_MUTED {str(params.get('state')).strip().upper()} >", target_port),
                "set_led_in_state": lambda: self._send_ok(ip, f"< SET DEV_LED_IN_STATE {self._toggle_state(params.get('state'), allow_toggle=False)} >", target_port),
                "recall_preset": lambda: self._send_ok(ip, f"< SET PRESET {self._channel_id(params.get('preset'))} >", target_port),
                "set_channel_mute": lambda: self._send_ok(ip, f"< SET {self._channel_id(params.get('channel'))} AUDIO_MUTE {self._toggle_state(params.get('state'))} >", target_port),
                "set_channel_gain_db": lambda: self._send_ok(ip, f"< SET {self._channel_id(params.get('channel'))} AUDIO_GAIN_HI_RES {self._db_to_gain(params.get('db'))} >", target_port),
                "adjust_channel_gain_db": lambda: self._adjust_channel_gain(ip, params.get("channel"), params.get("delta_db"), target_port),
                "reset_channel_gain": lambda: self._send_ok(ip, f"< SET {self._channel_id(params.get('channel'))} AUDIO_GAIN_HI_RES {self._db_to_gain(0)} >", target_port),
                "set_postgate_mute": lambda: self._send_ok(ip, f"< SET {self._channel_id(params.get('channel'))} AUDIO_MUTE_POSTGATE {self._toggle_state(params.get('state'), allow_toggle=False)} >", target_port),
                "set_postgate_gain_db": lambda: self._send_ok(ip, f"< SET {self._channel_id(params.get('channel'))} AUDIO_GAIN_POSTGATE {self._db_to_gain(params.get('db'))} >", target_port),
                "set_intellimix_bypass": lambda: self._send_ok(ip, f"< SET BYPASS_IMX {self._toggle_state(params.get('state'))} >", target_port),
                "set_eq_bypass": lambda: self._send_ok(ip, f"< SET BYPASS_ALL_EQ {self._toggle_state(params.get('state'), allow_toggle=False)} >", target_port),
                "set_eq_contour": lambda: self._send_ok(ip, f"< SET EQ_CONTOUR {self._toggle_state(params.get('state'), allow_toggle=False)} >", target_port),
                "set_channel_solo": lambda: self._send_ok(ip, f"< SET {self._channel_id(params.get('channel'))} CHAN_AUTOMIX_SOLO_EN {str(params.get('state')).strip().upper()} >", target_port),
                "set_channel_peq": lambda: self._send_ok(ip, f"< SET {self._channel_id(params.get('channel'))} PEQ 0 {str(params.get('state')).strip().upper()} >", target_port),
                "set_coverage_mute": lambda: self._send_ok(ip, f"< SET {self._channel_id(params.get('area'))} CA_MUTE {self._toggle_state(params.get('state'))} >", target_port),
                "set_coverage_gain_db": lambda: self._send_ok(ip, f"< SET {self._channel_id(params.get('area'))} CA_GAIN {self._db_to_gain(params.get('db'))} >", target_port),
                "adjust_coverage_gain_db": lambda: self._adjust_coverage_gain(ip, params.get("area"), params.get("delta_db"), target_port),
                "reset_coverage_gain": lambda: self._send_ok(ip, f"< SET {self._channel_id(params.get('area'))} CA_GAIN {self._db_to_gain(0)} >", target_port),
                "set_array_height": lambda: self._send_ok(ip, f"< SET ARRAY_HEIGHT {int(params.get('height_cm'))} >", target_port),
                "set_lobe_width": lambda: self._send_ok(ip, f"< SET {self._channel_id(params.get('lobe'))} BEAM_W {str(params.get('width')).strip().upper()} >", target_port),
                "set_lobe_x": lambda: self._send_ok(ip, f"< SET {self._channel_id(params.get('lobe'))} BEAM_X {int(params.get('value'))} >", target_port),
                "set_lobe_y": lambda: self._send_ok(ip, f"< SET {self._channel_id(params.get('lobe'))} BEAM_Y {int(params.get('value'))} >", target_port),
                "set_lobe_z": lambda: self._send_ok(ip, f"< SET {self._channel_id(params.get('lobe'))} BEAM_Z {int(params.get('value'))} >", target_port),
            }

            if action not in actions:
                return False, f"Unknown command: {action}"

            if action in {"set_led_color_unmuted", "set_led_color_muted"}:
                color = str(params.get("color", "")).strip().upper()
                if color not in self.ALL_COLORS:
                    return False, f"Invalid color '{color}'"
            if action in {"set_led_state_unmuted", "set_led_state_muted"}:
                state = str(params.get("state", "")).strip().upper()
                if state not in self.LED_STATES:
                    return False, f"Invalid LED state '{state}'"
            if action == "set_channel_solo":
                state = str(params.get("state", "")).strip().upper()
                if state not in self.SOLO_STATES:
                    return False, f"Invalid solo state '{state}'"
            if action == "set_channel_peq":
                state = str(params.get("state", "")).strip().upper()
                if state not in self.PEQ_STATES:
                    return False, f"Invalid PEQ state '{state}'"
            if action == "set_lobe_width":
                width = str(params.get("width", "")).strip().upper()
                if width not in self.LOBE_WIDTHS:
                    return False, f"Invalid lobe width '{width}'"

            return True, actions[action]()
        except Exception as e:
            return False, str(e)

    def query_status(self, ip, port=2202, display_id=None):
        info = self.get_device_info(ip, self._resolve_port(port), display_id)
        return {
            "reachable": info.get("current_status") == "Online",
            "device_name": info.get("device_name"),
            "model": info.get("model"),
            "serial_number": info.get("serial_number"),
            "firmware": info.get("firmware"),
            "muted": info.get("muted"),
            "auto_coverage": info.get("auto_coverage"),
            "error": info.get("error"),
        }
